# Astra v38 candidate

Parent: exact Fable v37 mist-c v14 allfit archive. Native C source, learned
move model and empirical history table are unchanged. The only playing change
is the separate modified Stockfish 19 scorer and ASTRA_SF_ALLCHILDREN=1.

The approximation scores all legal children in one full-window root pass.
It retains tactical search/NNUE but changes pruning/history trajectories.
Earlier development gates show faster leaf scoring and more search nodes;
these do not establish arena Elo. Release evidence and the final gate receipt
are in the repository's v38-manifest.json and v38-release.md beside this ZIP.

Run build.sh, then run.sh. The arena compiles the native engine. Stockfish is
prebuilt with portable CPU dispatch; its modified source/licence and offline
rebuild recipe are under third_party/stockfish19/. No GPU or network required.

Repository publication is separate from a human arena upload. The archive
label is not evidence of an assigned arena version.
