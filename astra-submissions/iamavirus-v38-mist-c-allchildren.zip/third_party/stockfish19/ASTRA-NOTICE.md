# Modified Stockfish 19

Original: official-stockfish/Stockfish tag sf_19 (release commit edb0d9d).
Source archive SHA256: 519b653d0d1ffb96531d982ccbe5c6a19425e8388e0e3c2f70f34b424ab32d76.
Licence: GPL-3.0-or-later; see Copying.txt and AUTHORS.

Astra modified src/search.h and src/search.cpp on 2 November 2026. The patch
enables an opt-in, single full-window root pass for depth-1 full MultiPV,
one-thread searches. Disabled, deeper and restricted-MultiPV paths retain
upstream behavior. This is an approximation; see astra-allchildren.patch.
The already-patched complete source and upstream build scripts are included.

The unmodified NNUE is embedded in ../../bin/stockfish and can be exported
without network access by rebuild.sh. Network SHA256: 1a298aa575a085434d29027978dc36867fe9c5bcea9376654b7a8eba1e52dfc2.
Build used Ubuntu 22.04, g++ 12.3.0, non-PGO official x86-64-universal target
with static libstdc++/libgcc. Requires glibc no newer than 2.35. See the project
repository's astra-submissions/analysis/v38-package-20261108 for build receipts.

Rebuild (outside the timed arena startup): sh rebuild.sh. This invokes the
included Makefile and requires g++-12, make, binutils, gawk, Python 3 and
hexdump (bsdextrautils). Do not ignore an absent NNUE embedding helper.
