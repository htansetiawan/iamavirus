#!/bin/sh
set -eu
cd "$(dirname "$0")"
# The exact upstream network is embedded in the shipped binary. Exporting it
# avoids storing a duplicate 98 MB copy in the arena workspace.
net=src/nn-1a298aa575a0.nnue
if [ ! -f "$net" ]; then
    printf 'export_net %s/%s\nquit\n' "$PWD" "$net" | ../../bin/stockfish
fi
printf '%s  %s\n' '1a298aa575a085434d29027978dc36867fe9c5bcea9376654b7a8eba1e52dfc2' "$net" | sha256sum -c -
cd src
command -v hexdump >/dev/null
make -j"${JOBS:-2}" build ARCH=x86-64-universal COMP=gcc CXX="${CXX:-g++-12}"
strip stockfish
test "$(wc -c < stockfish)" -gt 98000000
# Result: third_party/stockfish19/src/stockfish; installed bot is untouched.
