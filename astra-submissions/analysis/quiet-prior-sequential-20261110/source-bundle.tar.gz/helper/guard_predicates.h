static const int piece_pawns[6] = {1, 3, 3, 5, 9, 0};

static void queen_risks(const Belief *b, Move m, size_t cap, double temp, int threshold, double *r1, double *rt) {
    const size_t stride = b->count > cap ? (b->count + cap - 1) / cap : 1;
    double t1 = 0, l1 = 0, tt = 0, lt = 0;
    for (size_t i = 0; i < b->count; i += stride) {
        const double lw = b->logw ? (double)b->logw[i] : 0.0;
        const double wt = exp(lw), w1 = exp(lw / temp);
        Position p = b->items[i];
        t1 += w1; tt += wt;
        const int to = MOVE_TO(m);
        if (p.piece[to] == KING && p.color[to] != p.side) continue;   /* takes the king: won */
        int got = p.piece[to] != NO_PIECE && p.color[to] != p.side ? piece_pawns[p.piece[to]] : 0;
        if (!got && p.piece[MOVE_FROM(m)] == PAWN && to == p.ep) got = 1;
        Undo u;
        make_move(&p, m, &u);
        if (mover_left_king_capturable(&p)) continue;
        const int us = p.side ^ 1;
        int best = 0;
        for (int sq = 0; sq < 64; ++sq) {
            if (p.piece[sq] != QUEEN || p.color[sq] != us || !is_attacked(&p, sq, p.side)) continue;
            MoveList l; generate_moves(&p, &l);
            for (int j = 0; j < l.count; ++j) {
                if (MOVE_TO(l.moves[j]) != sq) continue;
                int gain = piece_pawns[QUEEN];
                Position q = p; Undo v; make_move(&q, l.moves[j], &v);
                if (is_attacked(&q, sq, us)) gain -= piece_pawns[p.piece[MOVE_FROM(l.moves[j])]];
                if (gain > best) best = gain;
            }
        }
        if (best - got >= threshold) { l1 += w1; lt += wt; }
    }
    *r1 = t1 > 0 ? l1 / t1 : 0;
    *rt = tt > 0 ? lt / tt : 0;
}

static void king_risks(const Belief *b, Move m, size_t cap, double temp, double *r1, double *rt) {
    const size_t stride = b->count > cap ? (b->count + cap - 1) / cap : 1;
    double t1 = 0, l1 = 0, tt = 0, lt = 0;
    for (size_t i = 0; i < b->count; i += stride) {
        const double lw = b->logw ? (double)b->logw[i] : 0.0;
        const double wt = exp(lw), w1 = exp(lw / temp);
        Position p = b->items[i];
        Undo u;
        make_move(&p, m, &u);
        t1 += w1; tt += wt;
        if (mover_left_king_capturable(&p)) { l1 += w1; lt += wt; }
    }
    *r1 = t1 > 0 ? l1 / t1 : 0;
    *rt = tt > 0 ? lt / tt : 0;
}
