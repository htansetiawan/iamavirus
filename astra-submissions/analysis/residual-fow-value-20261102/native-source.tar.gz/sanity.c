#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
size_t fow_residual_query_floats(void);
float fow_residual_query_logit(const float*,const uint8_t*,uint8_t,float);
float fow_residual_flat_logit(const float*,const uint8_t*,uint8_t,float);
int main(int argc,char **argv){
 if(argc!=6)return 2;FILE *f[5];for(int i=0;i<5;i++){f[i]=fopen(argv[i+1],"rb");if(!f[i])return 3;}
 size_t sizes[2]={160098,fow_residual_query_floats()};float *w[2];
 for(int i=0;i<2;i++){w[i]=malloc(sizes[i]*4);if(!w[i]||fread(w[i],4,sizes[i],f[i])!=sizes[i])return 4;}
 uint8_t x[320],h;float z;int count=0;double sum=0;
 while(fread(x,1,320,f[2])==320){if(fread(&h,1,1,f[3])!=1||fread(&z,4,1,f[4])!=1)return 5;
 float a=fow_residual_flat_logit(w[0],x,h,z),b=fow_residual_query_logit(w[1],x,h,z);
 if(!isfinite(a)||!isfinite(b))return 6;sum+=a+b;count++;}
 free(w[0]);free(w[1]);for(int i=0;i<5;i++)fclose(f[i]);printf("%d %.12f\n",count,sum);return count==256?0:7;
}
