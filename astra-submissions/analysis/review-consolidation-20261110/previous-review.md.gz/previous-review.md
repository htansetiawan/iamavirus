# November 10 review for Henry and Fable

**13:35UTC update:** [313 independent class-rank holdout](analysis/class-rank-holdout-20261110/README.md) rejects301's fixed scores:3,704primary/80games, gain0.009309<0.02nats, overlinear0.005978<0.01, CI[−0.005571,0.023496]. All source/course/scalar/invariant/aggregate checks pass. Close this configuration, with no posterior hook, sweep, match or ZIP; do not promote favorable opponent slices.307 is92/300 at13:22 and remains unscored/unchanged. Retain v38; finish307 before selecting another runtime change.

**13:09UTC update:** v38's13:04public snapshot is1946.47Elo/rank8,281W–18D–195L/494, with no listed technical loss. Greek Gift1–0–23 and Duck4–1–13 remain the large gap; Instructors13–1–14 and HYPOTHERMIA13–0–9 meet a more competitive standard. These are schedule-dependent records. [312](analysis/promotion-runtime-20261110/README.md) completes production build/protocol checks for310's bounded repair under all three archived compiler paths. The correction is still absent from live v38.307has73/300at13:01, no model scores or qualified successor.

**12:49UTC update:** [311 promotion reach](analysis/promotion-reach-20261110/README.md) checks302old v37 TRAIN games/27,135frames. Nonterminal king-safe promotion appears at77/13,445own decisions in44games; own/opponent-promotion union proxy144roots/62games. It is a targeted correctness repair, not the main large-Elo route. On the fixed Farsight belief,310allows only the previously excluded `a1=Q`; all other masks agree and the recorded king net remains. No policy or match was run. Keep307's frozen confirmation primary, with no intermediate model scores.

**12:35UTC update:** [309 predecessor diagnosis](analysis/farsight-root-20261110/README.md) retains the exact true state at0.246% and a2.22%-mass recorded net, missed by the32draw sample; existing guard alternatives are also removed. This is one reconstruction, not global calibration or an earned sampling fix. Separately, [310](analysis/promotion-ledger-20261110/README.md) provides a tested promotion-material accounting patch:21fixtures match exact course ledgers, ordinary queen-loss controls stay positive, incomplete root-only version is rejected. No change is merged or released; this is a Fable review artifact, with no strength claim.307 is still collecting unchanged.

**11:56UTC update:** [latest-ten v38 replay health](analysis/v38-latest-ten-20261110/README.md):4W–1D–5L,892frames pass both rules implementations, no technical losses. Two losses have no final-turn true-board escape; four are already8+ material down. The Farsight loss has a concrete guarded-bait net one turn before termination, with strictly limited oracle counterfactuals. This directs diagnosis earlier rather than just adding a terminal king veto. No new runtime change is selected. Farsight's rising v28 is outside307's fixed reference IDs; that scope stays unchanged. The latest metadata is1936.85Elo/rank9,264W–18D–186L/468; ten games are not a strength estimate.

**11:37UTC update:** the fresh [SSD-primary confirmation](analysis/prospective-full-prior-20261110b/README.md) is now launched before its fixed12:00UTC cutoff. Same frozen heads and numeric gates,4,996 old trajectories excluded,first300eligible new games. Twenty unit tests and the complete synthetic sourceaudit/scoring/independent reconstruction pass; these are correctness results only. Collector90873 and one-shot reviewer7176 are both alive, with no cores held while waiting and no future scores. The old295/302 remain closed/inconclusive. V38 retention is unchanged; no independently qualified successor, new ZIP or arena action.

**11:12UTC update:** Seagate disconnected again with kernel device-offline and lost-write errors. It is left unmounted; the closed-study SSD backup is preserved. Fable’s existing watcher is alive but failing to read the store. One complete public metadata refresh shows v38 at1928.05Elo,260W–17D–185L/462, with no listed non-board losses. This does not score or reopen295. A new confirmation needs SSD-primary output and tested cache-loss handling.

**10:52UTC update:** confirmation295 closed at196/300 after Seagate unmounted; no model scores or strength conclusion. Normal mounting restored the store and saved source/index hashes verify. The original295/302 processes remain terminal. A future attempt requires a separately published contract and new future cutoff with bounded SSD-primary storage. See[306](../chatroom/306-astra-storage-incident-and-closed-confirmation.md). The earlier recommendations below are historical context, not a running295 test.

**Retain v38. Finish the frozen prior confirmation before selecting the next
runtime change. There is no independently qualified replacement yet.**

This is a decision review, not a claim that the campaign is complete or that
Fable has agreed. It supersedes the November 9 review as a current summary;
that review and all original results remain available.

## Where we stand

Fable's **08:58 UTC November 10** checkpoint has v38 active at1940.6 Elo, rank 8,
250W–17D–173L over 440 games, with no recorded own technical loss. Its first 300
games passed the declared retention rule. Greek Gift remains1W–21L and Duck
4W–1D–11L in this version's record. The new Greek Gift win is encouraging but
does not overturn those matchup records. These are schedule-dependent arena
observations, not a controlled causal estimate against v35 or v37.

The deployed improvement is the all-child Stockfish scorer, roughly 1.6× faster
on the fixed scoring panel. It is approximate: its scores are not identical to
the old search. The local Misty gate failed; the human explicitly approved the
arena trial despite that failure. No later document should erase that history.
The immutable ZIP and version mapping are now recorded in both submission
indexes, and the public implementation page distinguishes v38 from the archived
v35 description. No new release number is reserved.

## What is open, and what would change the decision

| Priority | Evidence today | Next decision |
|---|---|---|
| 1. Frozen full-only prior confirmation, 295 | Earlier full quadratic gain 0.05120 nats over native and 0.03495 over linear; cheap missed its gate, so the combined configuration failed. The separately declared future test is collecting 300 trajectories after 07:15 UTC, with fixed weights and no interim scores. | All original count, effect, uncertainty, capture and priority-opponent safeguards plus independent verification must pass. A pass permits a separately specified native-cost and sequential-posterior test. A failure closes this frozen hypothesis; no threshold change, refit or favorable-slice rescue. |
| 2. Learned ranking with fixed observation-class evidence, 299–301 | Native class extraction matches 22,569 course-rule children. On 94 reused training examples, frozen quadratic ranking gains 0.04142 conditional temperature-two action nats; linear loses 0.00388. | This is only a necessary development signal. It needs a separate independent-cohort design. The current 295 cohort is not a selection set for this different mechanism. No filter hook or games are earned by the training result. |
| 3. A qualified playing comparison | Existing guard/sampling-only candidates failed. Some local Misty runs also lose all consistent boards at their configured cap, making those outcomes unsuitable as clean promotion evidence. | After a candidate passes its native/predictive requirements, use immutable deployed bytes and qualified opponents, full clocks, both colors, paired openings/seeds, exclusive cores, complete outcomes and source hashes. Public replay labels alone do not supply the opponents' current executables. |

Experiment 295 now has a bounded completion path: supervisor 67666 follows the original
collector 85819. On seal it runs **independent source audit → frozen scoring →
independent course/scalar verification**, once, with cores 0–1 and finite time
limits. It stops on failure, releases its own lease and writes a terminal
handoff. It does not train, retry, run matches, publish a ZIP or promote anything.
The data horizon remains 19:15 UTC; these execution mechanics change no gate.

## What the new constraint actually buys

For a hypothetical parent and our received view, let G contain its consistent
noncapturing opponent moves. The new rank operator reassigns the **existing**
post-history likelihoods within G. Thus, for every positive temperature τ,

    sum_G p_new(move | parent)^τ = sum_G p_old(move | parent)^τ.

At the deployed τ = 2, the parent retains the same unmerged mass for that
observation while the model can place it on different hidden moves. Captures
and masked moves retain their bits. This addresses a specific inference
tradeoff, not a general safety theorem. It also retains any wrongly calibrated
confidence spectrum. Merging, the guard's nonlinear fitted measure, later
observations, caps, histories and wall-clock thinning can change future behavior.
The measured training metric is conditional **action** likelihood, not posterior
truth mass, king safety, exploitability or Elo.

## Resources and the GPU decision

A fresh device probe this review found the RTX PRO 5000 available: 48,935 MiB
total, 752 MiB used, 0%utilization and no listed compute process. No service was
stopped. The GPU is available for a justified training plan; it is not the
current dependency for 295 or 301, which use small fixed CPU models.

The earlier teacher result needs a clear qualification. Experiment 237 beat
calibrated Stockfish on one test, but the same teacher **lost the broader 238
holdout**: log loss 0.47211 versus 0.46982 and worse Brier. The query student also
failed overall. Experiment 271's later compressed student missed its development
gate. Quantizing those models would reduce cost without establishing a better
target. The amortized MultiPV student 249 also failed its value and action-regret
conditions. These are closed configurations, not reasons for another sweep.

The zero-weight hidden-threat features are also old work: 094–109 added, fitted,
corrected and rejected them. The original two-feature fitter had a train/runtime
mismatch; its headline reduction must not guide selection. The corrected
specialist and all 28-feature refit had adverse selected-prefix/local evidence.
Their existence is not a new missing-feature discovery.

## Review checkpoints

The next useful report is the **audited 295 result**, not another partial NLL or
new architecture. If it passes, the native/posterior contract must state actual
full-branch coverage after clock thinning, capture-update parity from identical
parents, truth support and calibration on all outcomes, and equal-clock cost.
Playing promotion still requires full-game evidence. If it fails, take stock with
the committee before choosing another prior variant; preserve the negative result.

Sources: [295 contract](analysis/prospective-full-prior-20261110/README.md),
[301 result](analysis/learned-class-rank-20261110/README.md),
[302 continuation](analysis/prospective-auto-review-20261110/README.md),
[teacher replication limit](../chatroom/238-astra-query-attention-value.md),
[hidden-prior correction](../chatroom/109-astra-hidden-prior-fit-methodology-correction.md),
[research register](RESEARCH_REGISTER.md),
[v38 release mapping](../fable-submissions/README.md).


### 09:41 UTC follow-up: endgame specialist deprioritized

The primary endgame paper was already in the research record. Its draw-rule limit matters for arena claims. A bounded census now finds zero tested QK/RK/RRK-versus-bare-king configurations in302 old own training games /27,135 positions; independent C replay agrees. The opportunity gate fails, so no specialist is implemented. This is an old-panel finding, not current-v38 or all-endgame evidence. See [304](../chatroom/304-astra-endgame-theorem-and-opportunity-census.md). The independent checker initialization failure is preserved with its correction. Main future cohort is152/300; no model scores opened.


### Measurement qualification for the saved first300 trial

[305](../chatroom/305-astra-v38-measurement-uncertainty.md) reproduces the existing opponent-version/color matched advantage of6.45 points on230 games. Seventy unmatched games leave the full-schedule historical proxy between−4.72 and+18.61 points even before sampling noise, holding matched estimates fixed. A separate signed-weight uncertainty illustration requires fixed schedules and independent outcomes, which are not certified for the arena. Retention rules and the failed Misty result remain unchanged. No new model or295 data is used.
