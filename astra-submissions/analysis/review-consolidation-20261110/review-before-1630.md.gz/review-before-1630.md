# November 10 decision review for Henry and Fable

**Retain arena v38. Finish the already running full-prior confirmation before
selecting another runtime change. No replacement is independently qualified.**
Updated November 10, 2026; execution checked at 15:57 UTC. This is the current
review, replacing the accumulated status paragraphs. Historical claims and
closed tests remain in Git and the linked receipts. Fable agreement is not
assumed.

## What is playing, and what the record supports

V38 is the human-uploaded all-child Stockfish package, SHA-256
`ba6610f299c1589118ae335f3c46fbff802bf158456db9260ac911dce0d4f69f`.
Its C engine, fitted move model and history table match v37; the launcher and
Stockfish scorer differ. The engine maintains weighted consistent hidden
boards, samples worlds, grows an observation-history game tree, solves with
predictive CFR+, applies king/queen guards and purifies the root action. There
is no deployed deep policy/value network in this package. Offline learning
fits the move likelihoods and history counts; arena play does not retrain them.

The all-child scorer was about 1.6× faster on the frozen scoring panel, with
roughly 38% more equal-clock search nodes. It is approximate, not score-identical.
The direct-v37 pilot passed; the local Misty gate **failed**. Henry explicitly
accepted an experimental arena trial of those exact bytes. The first 300 arena
games scored 170W–10D–120L, 58.33%, above the predeclared 54.3% retention reference.
That is an operational reason to retain it, not a causal Elo estimate.

The latest complete public snapshot is **10:56 a.m. Boston / 15:56 UTC**:
**1,919.16 Elo, rank 10, 294W–19D–209L over 522 games**, v38 active, no listed
technical loss. Greek Gift v25 is 1W–23L; Duck v11 is 4W–1D–15L. Instructors v4
is 14W–1D–15L and HYPOTHERMIA v4 is 15W–11L. We are more competitive with the
latter two, while Greek Gift and Duck remain the clearest strength gaps.
These records depend on scheduling, versions and color. Seventy of the saved
first 300 games have no matching historical opponent-version/color cell; the
available adjustment does not establish v38's causal advantage.

[Release and trial](analysis/v38-arena-20261109/README.md),
[latest snapshot](analysis/v38-metadata-20261110T1556Z/result.json),
[opponent records](analysis/v38-metadata-20261110T1556Z/by-opponent.json),
[measurement limits](../chatroom/305-astra-v38-measurement-uncertainty.md).

## Decisions from today's work

| Work | Evidence | Decision |
|---|---|---|
| Full-only learned prior, 307 | Fixed 293 full quadratic head versus fixed linear and native controls. Original collector 90873 and reviewer 7176 are alive; 278/300 eligible new games at 15:57 UTC. No future model score yet. | Finish its frozen source audit → score → independent verification once. No interim accuracy, refit or cohort extension. |
| Fixed-spectrum hidden-move ranking, 313 | Independent 80-game holdout, 3,704 primary decisions: gain 0.009309 nats versus 0.020 required; advantage over linear 0.005978 versus 0.010; 95% game-cluster interval [−0.005571, 0.023496]. All source/course/scalar/capture/mask/permutation checks pass. | **Reject this fixed configuration.** No favorable-opponent rescue, parameter sweep, posterior hook, matches or ZIP. 301's positive training signal was not independent evidence. |
| Promotion material ledger, 310–312 | Complete arithmetic handles our promotion gain, opposing capture-promotion gain and recapturing the resulting piece. 21 course/native fixtures pass; exact isolated production patch passes all three archived compiler paths and both-color opening checks. | Correctness patch ready for Fable review, not deployed or strength-qualified. Incomplete root-only patch is explicitly rejected. |
| Ordinary exact updater acceleration, 225–227 | 1.986× faster isolated update with matching fingerprints, but whole-turn ratio 0.9272 and equal-clock nodes 1.0183 on the existing eight-pair panel. | Retain as engineering work. Do not claim doubled search or reopen a large-strength match batch on this evidence. |

The promotion fix is deliberately small in scope. In 302 old own v37 training
games, king-safe promotion occurs at 77/13,445 own decisions. On the fixed
Farsight belief it releases only the previously excluded queen promotion;
the recorded king net still exists. It is not the main route to a large gain.

The latest-ten replay review found 4W–1D–5L with all 892 frames matching the rules
and no technical failure. Four losses were already at least eight material
points down; two had no safe final-turn move on the true board. In one earlier
Farsight decision, the exact true state survived at 0.246% weight, and the
recorded net occupied 2.22% of the reconstructed belief but none of 32 draws.
That is a diagnostic, not proof that a sampling-only change saves the game:
guards and searched values also matter, and earlier guard/sampling rescues
failed. Investigate deterioration before the final king move.

[313 audited rejection](analysis/class-rank-holdout-20261110/README.md),
[promotion evidence](analysis/promotion-runtime-20261110/README.md),
[opportunity and masks](analysis/promotion-reach-20261110/README.md),
[Farsight diagnosis](analysis/farsight-root-20261110/README.md),
[research register](RESEARCH_REGISTER.md).

## Exactly what is running

307 is the **12:00 UTC November 10 cutoff**, not the interrupted 07:15 study.
The first 300 chronological eligible reference trajectories exclude 4,996 earlier
whole trajectories, include all outcomes/colors/versions, and use a bounded
128 MiB SSD archive. The earlier 196-game run remains permanently closed and
inconclusive, with no model scores. Its partial cohort is not being topped up.

Models, features, temperature, seed and gates are frozen. Primary examples are
reference-team decisions after eight own moves excluding demonstrated immediate
self-king losses. Require at least 5,000 primary decisions, mean gain ≥0.05 nats
over native and ≥0.02 over matched linear, a positive lower 95% game-cluster
bootstrap bound, all-move nonregression, exact capture preservation, at least
100 surprise captures, and each priority team ≥20 primary games with nonnegative
gain. Independent source/course/scalar/statistical review is required.

The collector polls every 20 minutes until its fixed horizon of **7 p.m. Boston
November 10 / 00:00 UTC November 11**. After seal, the existing reviewer claims
cores 0–1 and runs the three stages once under their fixed bounds. It holds no
cores while waiting. A missing handle, error, insufficient cohort or failed
gate closes this execution; it does not authorize a restart, threshold change
or selective scoring.

A pass permits **a separately specified native-cost and sequential-posterior
test**, not an arena candidate. Better action likelihood is not automatically
better posterior support, calibration, king/queen risk or equal-clock play.
Those requirements must be frozen before a subsequent test. A failure closes
this frozen hypothesis and triggers a committee review before another prior
variant. No release number is reserved; v38 must not be overwritten.

[Current 307 contract](analysis/prospective-full-prior-20261110b/plan.json),
[one-shot reviewer](analysis/prospective-review-20261110b/contract.json).

## Resources, learning and the next human decision

The Seagate failed twice and is left unmounted after kernel lost-write/offline
errors. The earlier confirmation's recovered prefix is preserved on SSD. Shared
raw/derived symlinks still refer to the unavailable store; fresh training export,
archive completion or taxonomy freshness cannot be claimed. The existing Fable
watcher is not replaced by a second daemon. 307 uses its explicit bounded SSD
fallback and writes no shared raw data. Stable storage needs attention before
restoring the broad daily learning loop; another blind remount is not planned.

The last host GPU probe, approximately 15:31 UTC, found the 48 GB RTX PRO 5000 idle; availability must be
rechecked before any training. No service was stopped and no GPU training is
running for these fixed CPU models. Earlier teacher/student, latent-type and
compressed-value configurations failed their own quality tests. A free GPU or
quantization does not make their targets better; those failures remain closed.

The next committee report is the **audited 307 result** with one recommendation,
not another growing list of untested architectures. Keep v38 in the arena,
review the bounded promotion repair separately, and judge a future strength
candidate with immutable deployed controls, full clocks, both colors, qualified
opponents, exclusive cores and complete outcomes. Public replays supply labels
and diagnoses; they are not executables that can act as the live Duck or
Instructors against our counterfactual moves.


## Data integrity repair completed after this review

[314](../chatroom/314-astra-dataset-journal-integrity.md) fixes a reproduced
shared episode-export defect: repeated accepted IDs previously gave a game
extra training weight. Duplicate and clean journals now produce identical
episodes; source conflicts, incomplete input or invalid accepted replays
preserve the last complete published dataset. Twelve focused tests pass,
including writer-lock scope and existing publication/split controls. This
changes future exports, not live v38 or any fitted weights. A full export is
still blocked by unavailable storage; the running confirmation's57pins match.


## Current speed budget measured after the review

[315](analysis/v38-search-cost-20261110/README.md) completes16 controlled
first attempts on the deployed v38 scorer with native max10-second cap.
CFR+strategy takes44.88% of search time; Stockfish48.24%. As shares of complete
target turns these are38.83% and41.74%. All source/course/timer checks pass.
The older255 figures used a different scorer and2.5-second cap, so this is
not an isolated causal scorer effect. It changes the budget we should use
for future engineering choices;254's earlier failed gate remains failed.
No automatic solver retest or new runtime selection before307 finishes.


## Structural learning inputs recovered locally

[316](analysis/reconstructed-train-20261110/README.md) reconstructs and fully
verifies4,000 old TRAIN traces /356,161 frames into a26MB private working
cache, using existing nibble packing and frozen move lists. No API or drive
access. This makes structural imitation/prior/representation data available;
clocks, recorded results, fresh full-corpus export and daily taxonomy remain
unavailable. Actor projection keeps hidden truth and labels out of features.
This is not a fitted model, independent test or strength gain.307 stays fixed.

[318](analysis/ragged-train-20261110/README.md) also recovers the exact original
TRAIN feature bytes into standard ragged storage:92,940contexts/3,080,303
candidates,372MB versus1002MB padded arrays. Export and separate decoded scan
both match293's original checksum; capture and fatal examples are retained.
This removes a data-loading prerequisite for later GPU work. No model head,
old validation/test or307 rows were processed; there is no new fit or model
quality claim, and actor policies must not consume these privileged features.
