#!/bin/bash
# Nothing to compile: the Rust extension is prebuilt for CPython 3.14 (x86-64,
# glibc >= 2.34) and Stockfish 19 is the official universal binary. This checks
# that both load in the runtime.
set -euo pipefail
cd "$(dirname "$0")"
chmod +x run.sh bin/stockfish
PYTHONPATH="$PWD/lib" FOW_REQUIRE_RUST=1 python3 -c "import fow_rust, fow_chess.engine_profile; print('build: fow_rust and fow_chess import')"
printf 'uci\nquit\n' | bin/stockfish | grep -m1 '^id name'
echo "build: done"
