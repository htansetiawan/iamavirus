"""Adapter: the course referee's stdin/stdout protocol <-> Misty (pip misty-chess).

Misty is Brian Liou's open implementation of Obscuro (GPL-3.0-or-later; its
source, licence and the Stockfish licence ship in this ZIP: LICENSE, src/,
bin/STOCKFISH-COPYING.txt). This adapter is the only code of ours here.

Protocol (fow-starter README): "fow", "<w|b> <base> <increment>", then a
64-character view (a1..h8; uppercase White, lowercase Black, '-' visible empty,
'?' unseen) before every ply, and our remaining seconds when it is our turn; we
answer "move <uci>".

Misty's Strategy protocol (fow_chess.selfplay): reset(color),
observe_own_move(move, Observation), observe_opp_move(Observation),
pick_move(PerspectiveView). Observation = visibility mask, visible pieces, and
the square where one of our pieces was captured (plus the capturer's landing
square when it is the same visible square).
"""
from __future__ import annotations

import os
import sys

import chess

from fow_chess.engine_profile import PROFILES
from fow_chess.observation import Observation
from fow_chess.selfplay import PerspectiveView
from fow_chess import engine_v2


def parse_view(text: str):
    visible = chess.SquareSet()
    pieces: dict[int, chess.Piece] = {}
    for square, ch in enumerate(text):
        if ch == "?":
            continue
        visible.add(square)
        if ch != "-":
            pieces[square] = chess.Piece.from_symbol(ch)
    return visible, pieces


def own_squares(text: str, color: bool) -> set[int]:
    return {sq for sq, ch in enumerate(text) if ch not in "?-" and ch.isupper() == (color == chess.WHITE)}


def view_board(text: str, color: bool, rights: dict[str, bool]) -> chess.Board:
    board = chess.Board(None)
    for square, ch in enumerate(text):
        if ch not in "?-":
            board.set_piece_at(square, chess.Piece.from_symbol(ch))
    board.turn = color
    fen_rights = ""
    if color == chess.WHITE:
        if rights["K"]: fen_rights += "K"
        if rights["Q"]: fen_rights += "Q"
    else:
        if rights["K"]: fen_rights += "k"
        if rights["Q"]: fen_rights += "q"
    board.set_castling_fen(fen_rights or "-")
    return board


def main() -> None:
    header = sys.stdin.readline().strip()
    if header != "fow":
        return
    side, base, increment = sys.stdin.readline().split()
    color = chess.WHITE if side == "w" else chess.BLACK
    inc_ms = int(float(increment) * 1000)
    profile = os.environ.get("MISTY_PROFILE", "v1.6")
    budget = float(os.environ.get("MISTY_BUDGET", "0")) or None
    strategy = PROFILES[profile].build_strategy(
        seed=int(os.environ.get("FOW_SEED", "1")),
        time_budget_seconds=budget,
        p_max_size=getattr(engine_v2, "_DEFAULT_P_MAX_SIZE", None),
    )
    strategy.reset(color)
    print("ready", flush=True)

    rights = {"K": True, "Q": True}
    home = 0 if color == chess.WHITE else 7
    king_home = chess.square(4, home)
    rook_k, rook_q = chess.square(7, home), chess.square(0, home)
    previous = None
    pending_own = None
    first = True
    for raw in sys.stdin:
        text = raw.strip()
        if len(text) == 64 and all(c in "PNBRQKpnbrqk-?" for c in text):
            visible, pieces = parse_view(text)
            if first:
                first = False  # the start position: nothing has moved yet
            elif pending_own is not None:
                strategy.observe_own_move(pending_own, Observation(visibility_mask=visible, visible_pieces=pieces))
                pending_own = None
            else:
                lost = own_squares(previous, color) - own_squares(text, color)
                captured = next(iter(lost)) if len(lost) == 1 else None
                landing = captured if captured is not None and captured in pieces and pieces[captured].color != color else None
                if captured in (rook_k, rook_q):
                    rights["K" if captured == rook_k else "Q"] = False
                strategy.observe_opp_move(Observation(visibility_mask=visible, visible_pieces=pieces,
                                                      own_capture_square=captured,
                                                      opp_capture_landing_square=landing))
            previous = text
            continue
        try:
            remaining = float(text)
        except ValueError:
            continue
        board = view_board(previous, color, rights)
        legal = list(board.pseudo_legal_moves)
        visible, pieces = parse_view(previous)
        view = PerspectiveView(perspective=color, own_legal_moves=legal, visible_squares=visible,
                               visible_piece_map=pieces, clock_remaining_ms=int(remaining * 1000),
                               increment_ms=inc_ms)
        move = strategy.pick_move(view)
        if move not in legal and legal:
            move = legal[0]  # never send an illegal move
        if move.from_square == king_home:
            rights["K"] = rights["Q"] = False
        if move.from_square == rook_k:
            rights["K"] = False
        if move.from_square == rook_q:
            rights["Q"] = False
        pending_own = move
        print(f"move {move.uci()}", flush=True)


if __name__ == "__main__":
    main()
