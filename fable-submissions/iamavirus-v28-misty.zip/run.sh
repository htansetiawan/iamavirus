#!/bin/bash
# Misty (github.com/brianhliou/misty, GPL-3.0-or-later) behind the course protocol.
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/lib${PYTHONPATH:+:$PYTHONPATH}"
export PATH="$PWD/bin:$PATH"
export FOW_STOCKFISH="$PWD/bin/stockfish"
export FOW_V2_CLOCK_TIME="${FOW_V2_CLOCK_TIME:-1}"
export FOW_REQUIRE_RUST=1
exec python3 -u misty_bot.py
