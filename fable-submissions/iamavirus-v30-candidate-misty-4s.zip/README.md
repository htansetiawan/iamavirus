# Misty for the course arena

The engine is **Misty** by Brian Liou (https://github.com/brianhliou/misty, commit in
`src/MISTY-COMMIT.txt`, PyPI `misty-chess` 0.1.3), GPL-3.0-or-later (`LICENSE`). It follows
Obscuro's architecture: exact belief enumeration, knowledge-limited subgames, one-sided GT-CFR
with PCFR+, Stockfish depth 1 at the leaves, and a resolve gadget when it commits a move.

Contents:
- `misty_bot.py`: our adapter between the course protocol and Misty's Strategy interface.
- `lib/fow_chess/`: Misty's Python package, unmodified.
- `lib/fow_rust/`: Misty's Rust extension, built from `src/fow_rust/` with rustc 1.85.1 for
  CPython 3.14 (`cargo build --release --offline --features pyo3/extension-module`).
- `bin/stockfish`: Stockfish 19, the official x86-64 universal binary (GPL-3.0,
  `bin/STOCKFISH-COPYING.txt`, source at https://github.com/official-stockfish/Stockfish).
- `run.sh` starts the adapter with `FOW_REQUIRE_RUST=1`, so a missing extension fails loudly
  instead of playing about 500 times slower.
- Arena time settings (v29): a 4 s search cap (3 s in v29), the commit guards on 200 belief boards each, and
  |P| capped at 500,000 (`MISTY_P_MAX`). With the library's defaults, arena moves took 10-18 s
  and two of v28's first six games were lost on time. If Misty raises (for example when its
  capped belief empties), the adapter rebuilds it from the observation history with a new seed,
  and otherwise plays a simple king-safe move rather than crash.
