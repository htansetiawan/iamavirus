#!/bin/bash
# Misty (github.com/brianhliou/misty, GPL-3.0-or-later) behind the course protocol.
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/lib${PYTHONPATH:+:$PYTHONPATH}"
export PATH="$PWD/bin:$PATH"
export FOW_STOCKFISH="$PWD/bin/stockfish"
export FOW_V2_CLOCK_TIME="${FOW_V2_CLOCK_TIME:-1}"
export FOW_REQUIRE_RUST=1
# a 3 s search cap: at the library's 5 s, arena moves took 10-13 s
export FOW_V2_TIME_HARD_CAP_S="${FOW_V2_TIME_HARD_CAP_S:-3.0}"
# the commit guards scan 1,000 belief boards each in pure Python (2-3 s a move
# here, about twice that on the arena); 200 keeps their fractions within ~2%
export FOW_COMMIT_RISK_WORLDS="${FOW_COMMIT_RISK_WORLDS:-200}"
export FOW_HV_PRUNE_WORLDS="${FOW_HV_PRUNE_WORLDS:-200}"
exec python3 -u misty_bot.py
