"""Adapter: the course referee's stdin/stdout protocol <-> Misty (pip misty-chess).

Misty is Brian Liou's open implementation of Obscuro (GPL-3.0-or-later; its
source, licence and the Stockfish licence ship in this ZIP: LICENSE, src/,
bin/STOCKFISH-COPYING.txt). This adapter is the only code of ours here.

Protocol (fow-starter README): "fow", "<w|b> <base> <increment>", then a
64-character view (a1..h8; uppercase White, lowercase Black, '-' visible empty,
'?' unseen) before every ply, and our remaining seconds when it is our turn; we
answer "move <uci>".

Misty's Strategy protocol (fow_chess.selfplay): reset(color),
observe_own_move(move, Observation), observe_opp_move(Observation),
pick_move(PerspectiveView). Observation = visibility mask, visible pieces, and
the square where one of our pieces was captured (plus the capturer's landing
square when it is the same visible square).
"""
from __future__ import annotations

import os
import sys
import time

import chess

from fow_chess.engine_profile import PROFILES
from fow_chess.observation import Observation
from fow_chess.selfplay import PerspectiveView
from fow_chess import engine_v2


def parse_view(text: str):
    visible = chess.SquareSet()
    pieces: dict[int, chess.Piece] = {}
    for square, ch in enumerate(text):
        if ch == "?":
            continue
        visible.add(square)
        if ch != "-":
            pieces[square] = chess.Piece.from_symbol(ch)
    return visible, pieces


def own_squares(text: str, color: bool) -> set[int]:
    return {sq for sq, ch in enumerate(text) if ch not in "?-" and ch.isupper() == (color == chess.WHITE)}


def view_board(text: str, color: bool, rights: dict[str, bool]) -> chess.Board:
    board = chess.Board(None)
    for square, ch in enumerate(text):
        if ch not in "?-":
            board.set_piece_at(square, chess.Piece.from_symbol(ch))
    board.turn = color
    fen_rights = ""
    if color == chess.WHITE:
        if rights["K"]: fen_rights += "K"
        if rights["Q"]: fen_rights += "Q"
    else:
        if rights["K"]: fen_rights += "k"
        if rights["Q"]: fen_rights += "q"
    board.set_castling_fen(fen_rights or "-")
    return board


VALUE = {chess.PAWN: 1, chess.KNIGHT: 3, chess.BISHOP: 3, chess.ROOK: 5, chess.QUEEN: 9, chess.KING: 100}


def fallback_move(board: chess.Board, legal: list, color: bool):
    """Only if Misty cannot answer: the best capture of a visible piece, else a
    move that leaves our king unattacked by any visible piece, else anything."""
    def king_safe(move):
        b = board.copy(stack=False)
        b.push(move)
        k = b.king(color)
        return k is not None and not b.is_attacked_by(not color, k)
    safe = [m for m in legal if king_safe(m)] or legal
    captures = [m for m in safe if board.piece_at(m.to_square) is not None]
    if captures:
        return max(captures, key=lambda m: VALUE[board.piece_at(m.to_square).piece_type])
    return safe[0] if safe else legal[0]


def main() -> None:
    header = sys.stdin.readline().strip()
    if header != "fow":
        return
    side, base, increment = sys.stdin.readline().split()
    color = chess.WHITE if side == "w" else chess.BLACK
    inc_ms = int(float(increment) * 1000)
    profile = os.environ.get("MISTY_PROFILE", "v1.6")
    budget = float(os.environ.get("MISTY_BUDGET", "0")) or None
    # |P| cap: unbounded enumeration (the library default) took 10-18 s a move
    # on the arena and lost two of v28's first six games on time
    p_max = int(os.environ.get("MISTY_P_MAX", "500000")) or None
    seed = int(os.environ.get("FOW_SEED", "1"))

    def build(s):
        st = PROFILES[profile].build_strategy(seed=s, time_budget_seconds=budget, p_max_size=p_max)
        st.reset(color)
        return st

    strategy = build(seed)
    history = []          # ("own", move, Observation) / ("opp", Observation): to rebuild after a failure
    broken = False        # Misty failed even after a rebuild: play the fallback from the view
    forced = [m for m in os.environ.get("MISTY_FORCE_MOVES", "").split(",") if m]   # replay tests only
    print("ready", flush=True)

    def feed(st, item):
        if item[0] == "own":
            st.observe_own_move(item[1], item[2])
        else:
            st.observe_opp_move(item[1])

    def recover(reason):
        """Misty raised (e.g. its belief emptied past the cap): rebuild with a new
        seed by replaying the observation history, else fall back for good."""
        nonlocal strategy, broken
        print(f"misty: {reason}; rebuilding from {len(history)} observations", file=sys.stderr, flush=True)
        for attempt in range(1, 3):
            try:
                st = build(seed + 7919 * attempt)
                for item in history:
                    feed(st, item)
                strategy = st
                print(f"misty: rebuilt (attempt {attempt})", file=sys.stderr, flush=True)
                return
            except Exception as error:   # noqa: BLE001
                print(f"misty: rebuild {attempt} failed: {error!r}", file=sys.stderr, flush=True)
        broken = True

    rights = {"K": True, "Q": True}
    home = 0 if color == chess.WHITE else 7
    king_home = chess.square(4, home)
    rook_k, rook_q = chess.square(7, home), chess.square(0, home)
    previous = None
    pending_own = None
    first = True
    for raw in sys.stdin:
        text = raw.strip()
        if len(text) == 64 and all(c in "PNBRQKpnbrqk-?" for c in text):
            visible, pieces = parse_view(text)
            if first:
                first = False  # the start position: nothing has moved yet
            elif pending_own is not None:
                item = ("own", pending_own, Observation(visibility_mask=visible, visible_pieces=pieces))
                history.append(item)
                if not broken:
                    try:
                        feed(strategy, item)
                    except Exception as error:   # noqa: BLE001
                        recover(f"observe_own_move raised {error!r}")
                pending_own = None
            else:
                lost = own_squares(previous, color) - own_squares(text, color)
                captured = next(iter(lost)) if len(lost) == 1 else None
                landing = captured if captured is not None and captured in pieces and pieces[captured].color != color else None
                if captured in (rook_k, rook_q):
                    rights["K" if captured == rook_k else "Q"] = False
                item = ("opp", Observation(visibility_mask=visible, visible_pieces=pieces,
                                           own_capture_square=captured,
                                           opp_capture_landing_square=landing))
                history.append(item)
                if not broken:
                    try:
                        feed(strategy, item)
                    except Exception as error:   # noqa: BLE001
                        recover(f"observe_opp_move raised {error!r}")
            previous = text
            continue
        try:
            remaining = float(text)
        except ValueError:
            continue
        board = view_board(previous, color, rights)
        legal = list(board.pseudo_legal_moves)
        visible, pieces = parse_view(previous)
        view = PerspectiveView(perspective=color, own_legal_moves=legal, visible_squares=visible,
                               visible_piece_map=pieces, clock_remaining_ms=int(remaining * 1000),
                               increment_ms=inc_ms)
        started = time.monotonic()
        move = None
        if not broken:
            try:
                move = strategy.pick_move(view)
            except Exception as error:   # noqa: BLE001
                recover(f"pick_move raised {error!r}")
                if not broken:
                    try:
                        move = strategy.pick_move(view)
                    except Exception as error2:   # noqa: BLE001
                        print(f"misty: pick_move failed again: {error2!r}", file=sys.stderr, flush=True)
                        broken = True
        if move is None or move not in legal:
            move = fallback_move(board, legal, color)
        if forced:   # replay tests: time Misty's decision, play the recorded move
            want = chess.Move.from_uci(forced.pop(0))
            move = want if want in legal else move
        try:
            size = strategy._engine.enumerator.size
            size = size() if callable(size) else size
        except Exception:   # noqa: BLE001
            size = -1
        print(f"misty: move {move.uci()} took {time.monotonic() - started:.2f}s |P|={size} clock={remaining:.1f}{' (fallback)' if broken else ''}",
              file=sys.stderr, flush=True)
        if move.from_square == king_home:
            rights["K"] = rights["Q"] = False
        if move.from_square == rook_k:
            rights["K"] = False
        if move.from_square == rook_q:
            rights["Q"] = False
        pending_own = move
        print(f"move {move.uci()}", flush=True)


if __name__ == "__main__":
    main()
